#!/usr/bin/env python
# coding: utf-8

# In[1]:


def selectionSortASC(data):
    for i in range(len(data) - 1): 
        for j in range(i+1, len(data), 1): 
            if data[i] > data[j]:
                data[i], data[j] = data[j], data[i]
    return data


# In[2]:


def selectionSortDESC(data):
    for i in range(len(data) - 1): 
        for j in range(i+1, len(data), 1):
            if data[i] < data[j]:
                data[i], data[j] = data[j], data[i]
    return data


# In[4]:


if __name__ == "__main__":
    data = [8, 3, 4, 9, 1]
    result = selectionSortASC(data)
    print("오름차순 정렬 결과 : {}".format(result))
    result = selectionSortDESC(data)
    print("내림차순 정렬 결과 : {}".format(result))

    

